# AI Recommendation System

recommendations={
    "technology":["Python Programming","Artificial Intelligence","Machine Learning Basics","Web Development","Cyber Security"],
    "sports":["Football","Cricket","Basketball","Badminton","Tennis"],
    "music":["Pop Music","Classical Music","Rock Music","Lo-fi Playlist","Jazz"],
    "movies":["Inception","Interstellar","Avengers: Endgame","The Dark Knight","The Matrix"],
    "books":["Atomic Habits","The Alchemist","Rich Dad Poor Dad","The Psychology of Money"],
    "travel":["Goa","Manali","Kerala","Ladakh","Jaipur"],
    "food":["Pizza","Biryani","Pasta","Burger","Dosa"]
}

def recommend(interest):
    interest=interest.lower().strip()
    if interest in recommendations:
        print("\nRecommended for you:")
        for i,item in enumerate(recommendations[interest],1):
            print(f"{i}. {item}")
    else:
        print("No recommendations found.")
        print("Available:", ", ".join(recommendations))

def main():
    print("AI Recommendation System")
    print("Categories:", ", ".join(recommendations))
    while True:
        recommend(input("\nEnter your interest: "))
        if input("Another recommendation? (yes/no): ").lower()!="yes":
            print("Thank you!")
            break

if __name__=="__main__":
    main()
