# AI Recommendation System

A simple rule-based recommendation system in Python.

## Run

``` bash
python recommendation_system.py
```

## Features

-   Takes user interests as input
-   Matches preferences using rule-based logic
-   Displays recommendations
